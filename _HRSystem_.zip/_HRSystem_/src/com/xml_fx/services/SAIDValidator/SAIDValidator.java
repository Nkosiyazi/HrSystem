/**
 * SAIDValidator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.xml_fx.services.SAIDValidator;

public interface SAIDValidator extends javax.xml.rpc.Service {
    public java.lang.String getSAIDValidatorSoapAddress();

    public com.xml_fx.services.SAIDValidator.SAIDValidatorSoap getSAIDValidatorSoap() throws javax.xml.rpc.ServiceException;

    public com.xml_fx.services.SAIDValidator.SAIDValidatorSoap getSAIDValidatorSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}

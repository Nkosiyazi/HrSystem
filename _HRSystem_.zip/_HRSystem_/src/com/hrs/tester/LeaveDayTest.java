package com.hrs.tester;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.hrs.dao.impl.EmployeeDaoImpl;
import com.hrs.dao.impl.LeaveDaoImpl;
import com.hrs.model.Leave;

public class LeaveDayTest 
{

	Leave leave = null;
	Leave tempLeave =  null;
	Set<Leave> leaveList = null;
			
	EmployeeDaoImpl edi = new EmployeeDaoImpl();
	
	Calendar leaveStart = GregorianCalendar.getInstance();
	Calendar leaveEnd = GregorianCalendar.getInstance();
	
	Date leaveStartDate = null;
	Date leaveEndDate = null;
	
	LeaveDaoImpl ldi = new LeaveDaoImpl();
			
	@Before
	public void setUpEmployeeLeave() throws ParseException
	{
	
		leave = new Leave();
		leaveList = new HashSet<Leave>();
						
		leave.setNoOfAvailableDays(21);
		leave.setNoOfDays(21);
		leave.setNoOfTakenDays(0);
		leave.setDepartmentManagerApproval("Yes");
		leave.setHrManagerApprovalStatus("No");

		leaveStart.set(2014, Calendar.AUGUST, 30);
		leaveEnd.set(2014, Calendar.SEPTEMBER, 1);
		
		leaveStartDate = leaveStart.getTime();
		leaveEndDate = leaveEnd.getTime();
		
		leave.setLeaveStartDate(leaveStartDate);
		leave.setLeaveEndDate(leaveEndDate);
		
		leave.setEmployee(null);
		
		leaveList.add(leave);
						
	}
	
	@After
	public void destroy()
	{
		leave = null;
		leaveList = null;
	}
	
	
	@Test
	public void insertLeave()
	{		
		ldi.saveLeave(leave);
	}
	
	@Test
	public void employeeLeaveTest()
	{
		assertEquals(leave.getDepartmentManagerApproval(), "Yes");
				
		leave.setHrManagerApprovalStatus("Approved");
				
		int requestedDays = ldi.calculateNumberOfDays(leaveStartDate, leaveEndDate);
		
		int leaveDays = ldi.validateLeaveDays(requestedDays,leave.getNoOfAvailableDays());
		
		String leaveStatus = ldi.leaveStatus(leaveDays);
		System.out.println(requestedDays+" : "+leaveStatus +"  "+leaveDays +"  "+leave.getNoOfAvailableDays());		
		assertEquals(leave.getHrManagerApprovalStatus(), leaveStatus);
		
		System.out.println(requestedDays+" : "+leaveStatus +"  "+leaveDays +"  "+leave.getNoOfAvailableDays());
	
		
	}
}

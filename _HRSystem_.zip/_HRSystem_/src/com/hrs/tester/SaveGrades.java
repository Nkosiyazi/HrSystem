package com.hrs.tester;

import static org.junit.Assert.*;

import org.junit.Test;

import com.hrs.dao.GradeDao;
import com.hrs.dao.impl.GradeDaoImpl;
import com.hrs.model.Grade;

public class SaveGrades {

	Grade grade = null;
	GradeDaoImpl gradeImp=null;
	@Test
	public void test() {
		
		
	}

}

package com.hrs.tester;

import static org.junit.Assert.assertNotNull;


import java.util.Date;

import org.junit.Ignore;
import org.junit.Test;

import com.hrs.dao.impl.AddressDaoImpl;
import com.hrs.dao.impl.EmployeeDaoImpl;
import com.hrs.dao.impl.JobDaoImpl;
import com.hrs.model.Address;
import com.hrs.model.Employee;
import com.hrs.model.Job;

public class EmployeeTester {

	Date dob = new Date();
	AddressDaoImpl addressDaoImpl = null;
	EmployeeDaoImpl empImp = null;
	Employee emp = null;
	
	//@Ignore
	@Test
	public void test()  {
	
		
		Address adress = new Address();
		Job job = new Job();
		emp = new Employee();
		
		addressDaoImpl = new AddressDaoImpl();
		adress.setHouseNo("houseNo");
		adress.setStreetName("Khali Street");
		adress.setSuburb("Harare");
		adress.setCityTown("Cape Town");
		adress.setPostalCode(7784);
	
		empImp = new EmployeeDaoImpl();
		
		
		/*SAIDValidatorSoapProxy proxy = new SAIDValidatorSoapProxy();
		
		SaidType saidType = proxy.validateIdString("", "8704275269081");
		
		
		if(saidType.isValid()== true)
		{*/
			emp.setDateOfBirth("1987/04/27");
			emp.setFirstName("Mohapi");
			emp.setLastName("Mokoena");
			emp.setMiddleName("Hapz");
			emp.setTitle("Mr");
			emp.setIdentityNumber("8704275269081");
			emp.setEmail("mMokoena@gmail.com");
			emp.setEthnicGroup("African");
			emp.setGender("Female");
			emp.setMaritalStatus("Single");
			//emp.setAddress(null);
			emp.setAcademic(null);
			emp.setJob(null);
			
			emp.setAddress(adress);
			adress.setEmployee(emp);
			
			empImp.registerEmployee(emp);

		
			//addressDaoImpl.saveAddress(adress);
			

		/*}
		
		else if(saidType.isValid()==false)
		{
			System.out.println("Please supply valid ID number");
		}
		else{
			System.out.println("xcnjdx");
		}*/
	}
	@Ignore
	@Test
	public void updateEmployee()
	{
		empImp = new EmployeeDaoImpl();
		emp = empImp.searchEmployee(1L);
		assertNotNull(emp);
		
		JobDaoImpl daoImpl = new JobDaoImpl();
		Job job= daoImpl.searchJob(1L);
		assertNotNull(job);
		emp.setJob(job);
		Long update= empImp.updateEmployee(emp);
		
		System.out.println("Ha ba shwe "+ update);
	}

}

package com.hrs.tester;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Blob;

import org.junit.Test;

import com.hrs.dao.impl.AcademicDaoImpl;
import com.hrs.dao.impl.EmployeeDaoImpl;
import com.hrs.model.Academic;
import com.hrs.model.Employee;

public class TestAcademic {

	Academic academic = null;
	AcademicDaoImpl academicDaoImpl = null;
	EmployeeDaoImpl daoImpl = null;
	Employee employee = null;
	
	@Test
	public void addTranscripts() {
		
		academic = new Academic();
		academicDaoImpl = new AcademicDaoImpl();
		daoImpl = new EmployeeDaoImpl();
		
		File file = new File("C:/Users/Hapz/Documents/Document.rtf");
		byte[] bFile = new byte[(int)file.length()];
		
		try{
			FileInputStream fileInputStream = new FileInputStream(file);
			fileInputStream.read(bFile);
			fileInputStream.close();
			
			academic.setAcademicName("Pasa");
			//academic.setCv(bFile);
			
			employee = daoImpl.searchEmployee(2L);
			academic.setEmployee(employee);
			Long id =academicDaoImpl.saveAcademic(academic);
			assertEquals(id, id);
			System.out.println("Saved");
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}	
	}
}

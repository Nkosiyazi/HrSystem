package com.hrs.tester;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.hrs.dao.impl.BankDaoImpl;
import com.hrs.dao.impl.EmployeeDaoImpl;
import com.hrs.model.Bank;
import com.hrs.model.Employee;

public class TestBanks {

	Bank bank = new Bank();
	BankDaoImpl bankImpl = new BankDaoImpl();
	EmployeeDaoImpl empImp = new EmployeeDaoImpl();
	@Ignore
	@Test
	public void addBank() {
		
		Employee employee = empImp.searchEmployee(1L);
		assertEquals(1L, 1L);
		bank.setBankName("FNB");
		bank.setBranchCode(5555);
		bank.setAccountType("saving");
		bank.setAccountNumber(40444640L);
		bank.setEmployee(employee);
		bank.setBranchName("Brandwag");
		Long id = bankImpl.saveBank(bank);
		assertEquals(id, id);
	}

	@Ignore
	@Test
	public void searchBank()
	{
		bank = bankImpl.getBank(1L);
		System.out.println("first list");
		System.out.println("");
		System.out.println("");
		
		//System.out.println(bank.getAccountType()+"\t\t"+ bank.getBankName()+"\t\t"+ bank.getAccountNumber());
	}
	@Test
	public void list()
	{
		System.out.println("First list");
		System.out.println("");
		System.out.println("");
		List<Bank> banks = bankImpl.bankList();
		for(Bank bank:banks)
		{
			System.out.println(bank.getBankName()+"\t\t"+ bank.getAccountType());
		}
		System.out.println("Second list");
		System.out.println("");
		System.out.println("");
		 banks = bankImpl.bankList();
		 for(Bank bank:banks)
			{
				System.out.println(bank.getBankName()+"\t\t"+ bank.getAccountType());
			}
	}
}

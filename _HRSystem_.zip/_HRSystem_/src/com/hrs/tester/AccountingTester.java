package com.hrs.tester;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.hrs.dao.impl.AccountingImpl;
import com.hrs.model.Accounting;


public class AccountingTester {

	Accounting acc = null;
	Accounting accTemp = null;
	AccountingImpl accImpl = null;
	String uniqueAccountingName = " ";
	Long accId = 0L;
	
	@Before
	public void setupAccountingData()
	{
		acc = new Accounting();
		accTemp = new Accounting();
		
		acc.setAccountingName("Me2");
		acc.setActualBudget(12);
		acc.setBudgetStatus("Approved");
		acc.setPredictiveBudget(14);
		acc.setPayroll(null);
		
		accImpl = new AccountingImpl();
				
	}
	
	@After
	public void destroy()
	{
		acc = null;
		accTemp = null;
		accImpl = null;
		uniqueAccountingName = null;
		accId = null;
		
	}
	
	public void insertData()
	{
		accId = accImpl.saveAccounting(acc);
				
		assertTrue("Id Saved",accId > 0L);
	}
	
	public void getData()
	{		
		accTemp = accImpl.getAccounting(uniqueAccountingName);
				
		assertEquals("Get Accounting by Name", accTemp.getAccountingName(), acc.getAccountingName());	
	}
	
	public void updateData()
	{
		
		accTemp.setActualBudget(120000.00);
		accTemp.setBudgetStatus(acc.getBudgetStatus());
		accTemp.setPredictiveBudget(acc.getPredictiveBudget());
		accTemp.setPayroll(null);
		accTemp.setAccountingName(acc.getAccountingName());
		
		accImpl.updateAccounting(accTemp);
		
		assertTrue("Updated account ",accTemp.getAccountingId() > 0L);
		
	}
	
	public void displayList()
	{
		assertNotNull(accImpl.getAccountingList());
		
		for(Accounting account:accImpl.getAccountingList())
		{
			System.out.println(" "+account.getAccountingName());
		}
	}
	
	@Test
	public void testData() {
				
		insertData();
		
		uniqueAccountingName = acc.getAccountingName();
		
		getData();
		
		updateData();
		
		displayList();
	}

}

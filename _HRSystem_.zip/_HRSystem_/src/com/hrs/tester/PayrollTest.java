package com.hrs.tester;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.hrs.dao.impl.PayrollImpl;

public class PayrollTest {


	@Test
	public void test() {
		PayrollImpl impl =new PayrollImpl();
		System.out.println("Print salaries");
		System.out.println("");
		impl.printSalaries();
	}

}

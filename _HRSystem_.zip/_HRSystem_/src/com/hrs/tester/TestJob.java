package com.hrs.tester;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

import com.hrs.dao.impl.DepartmentImpl;
import com.hrs.dao.impl.GradeDaoImpl;
import com.hrs.dao.impl.JobDaoImpl;
import com.hrs.model.Department;
import com.hrs.model.Grade;
import com.hrs.model.Job;

public class TestJob {
	
	Job job = new Job();
	JobDaoImpl impl = new JobDaoImpl();
	
	DepartmentImpl depImpl = new DepartmentImpl();
	GradeDaoImpl gradeImpl = new GradeDaoImpl();
	@Test
	public void addjob() {
		
		Department department = depImpl.getDepartment(1L);
		assertNotEquals(department, 1L);
		
		Grade grade = gradeImpl.getGrade(2L);
		assertNotEquals(grade, 2L);
		Date startDate = new Date();
		
		job.setDepartment(department);
		job.setJobCategory("Top Management");
		job.setJobDescription("Senior Programmer");
		job.setJobLevel("Proffessional");
		job.setJobLocation("Bloemfontein");
		job.setJobTitle("Senior Programmer");
		job.setJobType("Permanent");
		job.setNoOfPositions(2);
		job.getGrade().setSalary(35000.00);
		job.setStartDate(startDate);
		job.setGrade(grade);
		
		Long id = impl.saveJob(job);
		assertEquals(id, id);
	}

}

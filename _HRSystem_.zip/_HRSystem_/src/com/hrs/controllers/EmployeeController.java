    package com.hrs.controllers;


import java.net.URISyntaxException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.google.gson.Gson;
import com.hrs.dao.impl.EmployeeDaoImpl;
import com.hrs.model.Address;
import com.hrs.model.Bank;
import com.hrs.model.Employee;

@Path("/employeeController")
public class EmployeeController {
	
	EmployeeDaoImpl employeeDaoImpl = null; 
	
	JSONObject empObject = null;
	List<Employee> employeList = null;
	Address address = null;
	
	@POST
	@Path("addEmployee")
	@Consumes(MediaType.APPLICATION_JSON)
	public String addEmployee(Employee employee)
	{
		employeeDaoImpl = new EmployeeDaoImpl();
		Long empNum = employeeDaoImpl.registerEmployee(employee);
		
		return empNum.toString();
	}
	
	@PUT
	@Path("/updateEmployee")
	@Produces(MediaType.APPLICATION_JSON)
	public String updateEmployee(Employee employee)
	{
		employeeDaoImpl= new EmployeeDaoImpl();
		Long empNumber = employeeDaoImpl.updateEmployee(employee);
		return empNumber.toString();
	}
	
	@GET
	@Path("/employeeList")
	@Produces(MediaType.APPLICATION_JSON)
	public String employeeList() throws JSONException
	{
		employeeDaoImpl= new EmployeeDaoImpl();
		employeList =employeeDaoImpl.employeeList();
		
		JSONArray jsonArray = new JSONArray();
		
		for(int i=0;i<employeList.size();i++)
		{
		     empObject = new JSONObject();
			
			empObject.put("empNumber", employeList.get(i).getEmpNumber());
			empObject.put("email", employeList.get(i).getEmail());
			empObject.put("fristName", employeList.get(i).getFirstName());
			empObject.put("lastName", employeList.get(i).getLastName());
			empObject.put("empNumber", employeList.get(i).getIdentityNumber());
			empObject.put("empNumber", employeList.get(i).getJob().getJobTitle());
			
			jsonArray.put(empObject);
		}
		return jsonArray.toString();
	}
	
	@GET
	@Path("{empNumber}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getEmployee(@PathParam("empNumber")Long empNumber ) throws JSONException
	{
		
		empObject = new JSONObject();
		employeeDaoImpl= new EmployeeDaoImpl();
		Employee employee = employeeDaoImpl.searchEmployee(empNumber);
		empObject.put("", employee);
		return empObject.toString();
	}
	
	@GET
	@Path("login/{email}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response login(Employee emp ) throws URISyntaxException
	{
		java.net.URI location=null;
				
		if(emp.getPassword().equalsIgnoreCase(emp.getPassword())){
			
		
			location = new java.net.URI("http://localhost:8080/HRSystem/homePage.html"); 
		}
		
		return Response.seeOther(location).build();
	}
	
}

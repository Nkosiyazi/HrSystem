package com.hrs.controllers;

import java.util.List;

import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.hrs.dao.impl.BankDaoImpl;
import com.hrs.model.Bank;


@Path("/BankController")
public class BankController {

	BankDaoImpl bankDaoImpl = null;
	
	@POST
	@Path("/saveBankDetails")
	@Produces(MediaType.APPLICATION_JSON)
	public String saveBankDetails(Bank bank)
	{
		bankDaoImpl= new BankDaoImpl();
		Long bankId = bankDaoImpl.saveBank(bank);
		return bankId.toString();
	}
	@PUT
	@Path("/bankList")
	@Produces(MediaType.APPLICATION_JSON)
	public String bankList() throws JSONException
	{
		bankDaoImpl = new BankDaoImpl();
		List<Bank> bankList = bankDaoImpl.bankList();
		JSONArray bankArray = new JSONArray();
		
		for(Bank newbank:bankList)
		{
			JSONObject bankObject = new JSONObject();
			bankObject.put("bankId",newbank.getBankId());
			bankObject.put("branchCode",newbank.getBranchCode());
			bankObject.put("bankName",newbank.getBankName());
			bankObject.put("branchName",newbank.getBranchName());
			bankArray.put(bankObject);
		}
		
		return bankArray.toString();
	}
}

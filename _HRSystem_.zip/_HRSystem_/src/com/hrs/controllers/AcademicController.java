package com.hrs.controllers;


import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;


import com.hrs.dao.impl.AcademicDaoImpl;
import com.hrs.model.Academic;


@Path("/academicController")
public class AcademicController {
	
	AcademicDaoImpl academicDao = new AcademicDaoImpl();
	
	@Path("/saveAcademic")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response saveJsonAcademic(Academic academic)
	{
		 
		academicDao.saveAcademic(academic);
		return Response.status(Status.CREATED).build();
	} 
	public Response removeDocuments(Long academicId)
	{
		academicDao.removeAcademic(academicId);
		return Response.status(Status.CREATED).build();
	}
}

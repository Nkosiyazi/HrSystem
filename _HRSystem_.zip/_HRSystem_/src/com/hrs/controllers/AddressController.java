package com.hrs.controllers;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.hrs.dao.impl.AddressDaoImpl;
import com.hrs.model.Address;

@Path("/AddressController")
public class AddressController {
	
     AddressDaoImpl addressDaoImpl =null;
     
     @POST
     @Path("/saveAddress")
     @Produces(MediaType.APPLICATION_JSON)
     public String saveAddress(Address address)
     {
    	 
    	 addressDaoImpl = new AddressDaoImpl();
    	 Long addressId= addressDaoImpl.saveAddress(address);
    	 return addressId.toString();
     }
     @PUT
     @Path("/updateAddress")
     @Produces(MediaType.APPLICATION_JSON)
     public String updateAddress(Address address)
     {
    	 addressDaoImpl = new AddressDaoImpl();
    	 Long addressId = addressDaoImpl.updateAddress(address.getAddressId(), address);
    	 
    	 return addressId.toString();
     }
     
	@GET
	@Path("{addressId}")
	@Produces(MediaType.APPLICATION_JSON)
	 public String getAddress(@PathParam("addressId")Long addressId) throws JSONException
	{
		addressDaoImpl = new AddressDaoImpl();
		Address address = addressDaoImpl.searchAddress(addressId);
		JSONObject addressObject = new JSONObject();
		addressObject.put("", address);
		return addressObject.toString();
	}
}

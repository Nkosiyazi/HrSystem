package com.hrs.controllers;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.hrs.dao.impl.*;

import com.hrs.model.Grade;
@Path(value="/GradeController")
public class GradeController {
	GradeDaoImpl gradeDaoImpl= null;
	
	@Path( value ="/SaveGrade")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response SaveGrade(Grade grade){
		gradeDaoImpl = new GradeDaoImpl();
		gradeDaoImpl.saveGrade(grade);
		return Response.status(200).build();
		
	}
	@PUT
	@Path(value="/UpdateAccounts")
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateAcconts(@PathParam("garadeId")Long garadeId,Grade grade){
		gradeDaoImpl = new GradeDaoImpl();
		gradeDaoImpl.updateGrade(garadeId, grade);
		return Response.status(200).build();
		
	}
	@Path(value="{garadeId}")
	@GET

	@Produces(MediaType.APPLICATION_JSON)
	public String getGrade(@PathParam("garadeId")Long garadeId){
		gradeDaoImpl = new GradeDaoImpl();
		Grade grade=gradeDaoImpl.getGrade(garadeId);
		return grade.toString();
	}

	@Path(value="/gradesList")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String viewAccounts()throws  JSONException{
		
		gradeDaoImpl = new GradeDaoImpl();
		List<Grade>gradeList=gradeDaoImpl.gradesList();
		
		JSONArray jsonArray = new JSONArray();
		
		for(int i=0;i<gradeList.size();i++)
		{
			JSONObject GradeObject = new JSONObject();
			
			GradeObject.put("garadeId", gradeList.get(i).getGradeId());
			GradeObject.put("gradeType", gradeList.get(i).getGradeType());
			GradeObject.put("salary", gradeList.get(i).getSalary());
			GradeObject.put("carAllowenceAmount", gradeList.get(i).getCarAllowanceAmount());
			GradeObject.put("houseAllowenceAmount", gradeList.get(i).getHouseAllowanceAmount());
			
			
			jsonArray.put(GradeObject);

		
	}
		return jsonArray.toString() ;
	}
}

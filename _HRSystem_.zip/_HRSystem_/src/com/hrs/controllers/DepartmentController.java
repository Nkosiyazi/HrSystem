package com.hrs.controllers;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.hrs.dao.impl.DepartmentImpl;
import com.hrs.model.Department;

@Path("/DepartmentController")
public class DepartmentController {
	DepartmentImpl departImple =null; 
	
	@POST
	@Path("saveDepartment")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public String saveDepartment(Department department){
		
		departImple = new DepartmentImpl();
	    Long demartmentId = departImple.saveDepartment(department);
	    return demartmentId.toString();
	}
	
	@Produces(MediaType.APPLICATION_JSON)
	@PUT
	@Path("/updateDepartment")
	public String updateDepartment(Department department)
	{
		departImple = new DepartmentImpl();
	    departImple.updateDepartment(department);
		return department.getDepartmentId().toString();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/departmentList")
	public String departmentList() throws JSONException
	{
		departImple = new DepartmentImpl();
		List<Department> allDepartments = departImple.getDepartmentList();
		
		JSONArray departmentArray = new JSONArray();
		
		for(int i=0; i< allDepartments.size();i++)
		{
			JSONObject departmentObject = new  JSONObject();
			
			departmentObject.put("departmentId", allDepartments.get(i).getDepartmentId());
			departmentObject.put("departmentName", allDepartments.get(i).getDepartmentName());
			departmentObject.put("departmentBuilding", allDepartments.get(i).getDepartmentBuilding());
			departmentObject.put("departmentLocation", allDepartments.get(i).getDepartmentLocation());
			
			departmentArray.put(departmentObject);
		}
		return departmentArray.toString();
	}
	
	@Path("{departmentId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String getDepartment(@PathParam("departmentId")Long departmentId) throws JSONException
	{
		departImple = new DepartmentImpl();
		Department department = departImple.getDepartment(departmentId);
		JSONObject departmentObject = new  JSONObject();
		departmentObject.put("", department);
		return departmentObject.toString();
	}

}

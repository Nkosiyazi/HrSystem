package com.hrs.controllers;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.hrs.dao.impl.TrainingImpl;
import com.hrs.model.Accounting;
import com.hrs.model.Training;

@Path(value="/TrainingController")
public class TrainingController {
	TrainingImpl trainingImpl=new TrainingImpl();
	@Path(value="/SaveTraining")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response posting(Training training){
		
		trainingImpl.saveTraining(training);
		return Response.status(200).build() ;
	}

	@PUT
	@Path(value="/UpdateTraining")
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateTraining(Training training){
		trainingImpl.updateTraining(training);
		return Response.status(200).build();
		
	}
	@Path(value="{trainingnName}")
	@GET

	@Produces(MediaType.APPLICATION_JSON)
	public String getAccount(@PathParam("trainingnName")String trainingnName){
		Training training=trainingImpl.getTraining(trainingnName);
		return training.toString();
	}

	@Path(value="/ViewAllTraining")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String viewAccounts()throws  JSONException{
		List<Training>trainingsList=trainingImpl.getTrainingList();
		
		JSONArray jsonArray = new JSONArray();
		
		for(int i=0;i<trainingsList.size();i++)
		{
			JSONObject trainingObject = new JSONObject();
			trainingObject.put("trainingId", trainingsList.get(i).getTrainingId());
			trainingObject.put("trainingnName", trainingsList.get(i).getTrainingnName());
			trainingObject.put("trainingLocation", trainingsList.get(i).getTrainingLocation());
			trainingObject.put("trainingDescription", trainingsList.get(i).getTrainingDescription());
			trainingObject.put("skillDetails", trainingsList.get(i).getSkillDetails());
			trainingObject.put("startingDate", trainingsList.get(i).getStartingDate());
			trainingObject.put("endDate", trainingsList.get(i).getEndDate());
			
			
			
			jsonArray.put(trainingObject);

		
	}
		return jsonArray.toString() ;
	}
}

package com.hrs.controllers;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.hrs.dao.impl.JobDaoImpl;
import com.hrs.model.Job;


@Path("/JobController")
public class JobController {
	
	
	JobDaoImpl jobDaoImpl = null;
	
	@POST
	@Path("/saveJob")
	@Produces(MediaType.APPLICATION_JSON)
	public String saveJob(Job job)
	{
		jobDaoImpl = new JobDaoImpl();
		Long jobId = jobDaoImpl.saveJob(job);
		return jobId.toString();
	}
	@PUT
	@Path("/updateJob")
	@Produces(MediaType.APPLICATION_JSON)
	public String updateJabo(Job job)
	{
		jobDaoImpl = new JobDaoImpl();
		Long jobId = jobDaoImpl.updateJob(job);
		
		return jobId.toString();
	}
	@GET
	@Path("{jobId}")
	@Consumes(MediaType.APPLICATION_JSON)
	public String getJob(@PathParam("jobId")Long jobId) throws JSONException
	{
		jobDaoImpl = new JobDaoImpl();
		Job job = jobDaoImpl.searchJob(jobId);
		JSONObject jobObect = new JSONObject();
		jobObect.put("", job);
		
		return jobObect.toString();
	}
	@GET
	@Path("/jobList")
	@Consumes(MediaType.APPLICATION_JSON)
	public String jobList() throws JSONException
	{
		jobDaoImpl = new JobDaoImpl();
		List<Job> jobs = jobDaoImpl.jobList();
		JSONArray jsonArray = new JSONArray();
		for(Job job:jobs)
		{
			JSONObject jobObject = new JSONObject();
			
			jobObject.put("jobId", job.getJobId());
			jobObject.put("jobTitle", job.getJobTitle());
			jobObject.put("jobCategory", job.getJobCategory());
			jobObject.put("startDate", job.getStartDate());
			jobObject.put("noOfPositions", job.getNoOfPositions());
			//jobObject.put("department", job.getDepartment().getDepartmentName());
			
			jsonArray.put(jobObject);
		}
		return jsonArray.toString();
	}

}

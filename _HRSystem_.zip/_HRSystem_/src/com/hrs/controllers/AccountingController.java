package com.hrs.controllers;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.hrs.dao.impl.AccountingImpl;
import com.hrs.model.Accounting;



@Path("/AccountingController")
public class AccountingController {
	AccountingImpl AccountingImpl=new AccountingImpl();
@Path(value="/SaveAccounts")
@POST
@Consumes(MediaType.APPLICATION_JSON)
public Response posting(Accounting accounting){
	
	AccountingImpl.saveAccounting(accounting);
	return Response.status(200).build() ;
}

@PUT
@Path(value="/UpdateAccounts")
@Produces(MediaType.APPLICATION_JSON)
public Response updateAcconts(Accounting accounting){
	AccountingImpl.updateAccounting(accounting);
	return Response.status(200).build();
	
}
@Path(value="{accountingName}")
@GET

@Produces(MediaType.APPLICATION_JSON)
public String getAccount(@PathParam("accountingName")String accountingName){
	Accounting accounts=AccountingImpl.getAccounting(accountingName);
	return accounts.toString();
}

@Path(value="/ViewAllAccounts")
@GET
@Produces(MediaType.APPLICATION_JSON)
public String viewAccounts()throws  JSONException{
	List<Accounting>accountsList=AccountingImpl.getAccountingList();
	
	JSONArray jsonArray = new JSONArray();
	
	for(int i=0;i<accountsList.size();i++)
	{
		JSONObject AccountObject = new JSONObject();
		
		AccountObject.put("accountingId", accountsList.get(i).getAccountingId());
		AccountObject.put("accountingName", accountsList.get(i).getAccountingName());
		AccountObject.put("actualBudget", accountsList.get(i).getActualBudget());
		AccountObject.put("predictiveBudget", accountsList.get(i).getPredictiveBudget());
		AccountObject.put("budgetStatus", accountsList.get(i).getBudgetStatus());
		
		
		jsonArray.put(AccountObject);

	
}
	return jsonArray.toString() ;
}
}

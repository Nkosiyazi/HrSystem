package com.hrs.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="tblGrades")
@XmlRootElement
@NamedQueries({
	                   @NamedQuery(name = "SearchGrade", query = "from Grade where garadeId=? "),
		               @NamedQuery(name = "ListGrades", query = " from Grade" )
	                   })
public class Grade implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)	
	private Long gradeId;
	
	@Column(name="tblGrade_Type")
	private String gradeType;
	
	@Column(name="tblGrade_Salary")
	private double salary;
	
	@Column(name="tblGrade_CarAllowance")
	private double carAllowanceAmount;
	
	@Column(name="tblHouseAllawence")
	private double houseAllowanceAmount;
	
	@OneToMany(mappedBy ="grade",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private Set<Job> jobs;
	
	
	
	
	
    private double uifDeduction;
    private double pensionDeduction;
    private double netSalary;
    private double commissionAmount;
	public Long getGradeId() {
		return gradeId;
	}

	public void setGradeId(Long gradeId) {
		this.gradeId = gradeId;
	}

	public String getGradeType() {
		return gradeType;
	}
     
	public double getCommissionAmount() {
		return commissionAmount;
	}

	public void setCommissionAmount(double commissionAmount) {
		this.commissionAmount = commissionAmount;
	}

	public void setGradeType(String gradeType) {
		this.gradeType = gradeType;
	}

	public double getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(double netSalary) {
		this.netSalary = netSalary;
	}

	public double getSalary() {
		return salary;
	}

	
	public void setSalary(double salary) {
		this.salary = salary;
	}

	public double getCarAllowanceAmount() {
		return carAllowanceAmount;
	}

	public void setCarAllowanceAmount(double carAllowanceAmount) {
		this.carAllowanceAmount = carAllowanceAmount;
	}

	public double getHouseAllowanceAmount() {
		return houseAllowanceAmount;
	}

	public void setHouseAllowanceAmount(double houseAllowanceAmount) {
		this.houseAllowanceAmount = houseAllowanceAmount;
	}

	public Set<Job> getJobs() {
		return jobs;
	}

	public void setJobs(Set<Job> jobs) {
		this.jobs = jobs;
	}

	public double getUifDeduction() {
		return uifDeduction;
	}

	public void setUifDeduction(double uifDeduction) {
		this.uifDeduction = uifDeduction;
	}

	public double getPensionDeduction() {
		return pensionDeduction;
	}

	public void setPensionDeduction(double pensionDeduction) {
		this.pensionDeduction = pensionDeduction;
	}

	public Grade() {
		// TODO Auto-generated constructor stub
	}
	
	
}

package com.hrs.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;
@Entity
@NamedQueries
({
	@NamedQuery(name="Employee.byId",query="from Employee  where empNumber =?"),
	@NamedQuery(name="Employee.byList", query="from Employee"),
	@NamedQuery(name="Employee.byEmail", query="from Employee where email =?")
})
@Table(name="tblEmployee")
@XmlRootElement
public class Employee implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long empNumber;
	
	@Column(name = "tblEmployee_FirstName")//@NotBlank @NotEmpty
	private String firstName;
	
	@Column(name = "tblEmployee_MiddleName")//@NotBlank @NotEmpty
	private String middleName;
	
	@Column(name = "tblEmployee_IdentityNumber")//@Size(min = 13, max = 13)@NotNull
	private String identityNumber;
	
	@Column(name = "tblEmployee_LastName")//@NotBlank @NotEmpty
	private String lastName;
	
	@Column(name = "tblEmployee_Title")//@NotBlank @NotEmpty
	private String title;
	
	@Column(name = "tblEmployee_Gender")//@NotBlank @NotEmpty
	private String gender;
	
	@Column(name = "tblEmployee_DateOfBirth")//@NotBlank @NotEmpty
	private String dateOfBirth;
	
	@Column(name = "tblEmployee_Email")//@NotBlank @NotEmpty
	private String email;
	
	@Column(name = "tblEmployee_MaritalStatus")//@NotBlank @NotEmpty
	private String maritalStatus;
	
	@Column(name = "tblEmployee_EthnicGroup")//@NotBlank @NotEmpty
	private String ethnicGroup;
	
	@Column(name = "tblEmployee_IsActive")//@NotBlank @NotEmpty
	private boolean isActive;
	
	@Column(name = "tblEmployee_Password")
	private String password;
	
	@OneToOne(mappedBy="employee",cascade= CascadeType.ALL)
	private Bank bank;
	
	@OneToOne(mappedBy ="employee", cascade= CascadeType.ALL)
	private Address address;
	
	@ManyToOne
	@JoinColumn(name="tblJob_Id")
	private Job job;
	
	@OneToMany(mappedBy ="employee", cascade= CascadeType.ALL)
	private Set<Leave> leave;
	
	@OneToMany(mappedBy="employee", cascade= CascadeType.ALL)
	private Set<Academic> academic;
	
	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL)
	private Set<SaleCommission> saleCommission;
	
	@ManyToOne
	@JoinColumn(name="tblTraining_Id")
	private Training training;
	
	@OneToMany(mappedBy="employee",cascade=CascadeType.ALL)
	private Set<TimesheetAttendance> timesheetAttandance;
	
	public Employee() {
		
	}

	public Long getEmpNumber() {
		return empNumber;
	}
	public void setEmpNumber(Long empNumber) {
		this.empNumber = empNumber;
	}
	public String getFirstName() {
		return firstName;
	}




	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}




	public String getMiddleName() {
		return middleName;
	}




	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}




	public String getIdentityNumber() {
		return identityNumber;
	}




	public void setIdentityNumber(String identityNumber) {
		this.identityNumber = identityNumber;
	}




	public String getLastName() {
		return lastName;
	}




	public void setLastName(String lastName) {
		this.lastName = lastName;
	}




	public String getTitle() {
		return title;
	}




	public void setTitle(String title) {
		this.title = title;
	}




	public String getGender() {
		return gender;
	}




	public void setGender(String gender) {
		this.gender = gender;
	}




	public String getDateOfBirth() {
		return dateOfBirth;
	}




	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}




	public String getEmail() {
		return email;
	}




	public void setEmail(String email) {
		this.email = email;
	}




	public String getMaritalStatus() {
		return maritalStatus;
	}




	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}




	public String getEthnicGroup() {
		return ethnicGroup;
	}




	public void setEthnicGroup(String ethnicGroup) {
		this.ethnicGroup = ethnicGroup;
	}




	public boolean isActive() {
		return isActive;
	}




	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}




	public Bank getBank() {
		return bank;
	}




	public void setBank(Bank bank) {
		this.bank = bank;
	}




	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Address getAddress() {
		return address;
	}




	public void setAddress(Address address) {
		this.address = address;
	}




	public Job getJob() {
		return job;
	}




	public void setJob(Job job) {
		this.job = job;
	}




	public Set<Leave> getLeave() {
		return leave;
	}




	public void setLeave(Set<Leave> leave) {
		this.leave = leave;
	}




	public Set<Academic> getAcademic() {
		return academic;
	}




	public void setAcademic(Set<Academic> academic) {
		this.academic = academic;
	}




	public Training getTraining() {
		return training;
	}




	public void setTraining(Training training) {
		this.training = training;
	}




	public Set<TimesheetAttendance> getTimesheetAttandance() {
		return timesheetAttandance;
	}




	public void setTimesheetAttandance(Set<TimesheetAttendance> timesheetAttandance) {
		this.timesheetAttandance = timesheetAttandance;
	}




	public Set<SaleCommission> getSaleCommission() {
		return saleCommission;
	}




	public void setSaleCommission(Set<SaleCommission> saleCommission) {
		this.saleCommission = saleCommission;
	}
}

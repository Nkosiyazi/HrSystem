package com.hrs.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "tblPayroll")

@NamedQueries
({
	@NamedQuery(name="findPayrollByName",query="from Payroll  where payrollName =:payrollName"),
	@NamedQuery(name="getPayrollList", query="from Payroll")
	
})

@XmlRootElement
public class Payroll implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2081233512939414568L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long payrollId;
	
	@NotNull
	@Column(name ="tblPayroll_Name")
	private String payrollName;
	
	@NotNull
	@Column(name ="tblPayroll_Description")
	private String payrollDescription;
	
	@ManyToOne
	private Accounting accounting;
	
	@OneToMany(mappedBy="payroll",cascade=CascadeType.ALL)
	private Set<TimesheetAttendance> timesheetAttandances;
	
	public Payroll() {
	}

	public Long getPayrollId() {
		return payrollId;
	}

	public void setPayrollId(Long payrollId) {
		this.payrollId = payrollId;
	}

	public Accounting getAccounting() {
		return accounting;
	}

	public void setAccounting(Accounting accounting) {
		this.accounting = accounting;
	}

	public Set<TimesheetAttendance> getTimesheetAttandances() {
		return timesheetAttandances;
	}

	public void setTimesheetAttandances(
			Set<TimesheetAttendance> timesheetAttandances) {
		this.timesheetAttandances = timesheetAttandances;
	}

	public String getPayrollName() {
		return payrollName;
	}

	public void setPayrollName(String payrollName) {
		this.payrollName = payrollName;
	}

	public String getPayrollDescription() {
		return payrollDescription;
	}

	public void setPayrollDescription(String payrollDescription) {
		this.payrollDescription = payrollDescription;
	}
	
	
}

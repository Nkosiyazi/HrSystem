package com.hrs.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
@Table(name ="tblAccounting")

@NamedQueries
			({
				@NamedQuery(name="findAccountingByName",query="from Accounting  where accountingName =:accountingName"),
				@NamedQuery(name="getAccoutingList", query="from Accounting")
				
			})
public class Accounting implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2340167472387149127L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long accountingId;
	
	@NotNull
	@Column(name = "tblAccounting_Name",unique=true)
	private String accountingName;
	
	@NotNull
	@DecimalMin("0.00")
	@Column(name = "tblAccounting_ActualBudget")
	private double actualBudget;
		
	@NotNull
	@DecimalMin("0.00")
	@Column(name = "tblAccounting_PredictiveBudget")
	private double predictiveBudget;
	
	@NotNull
	@Column(name = "tblAccounting_BudgetStatus")
	private String budgetStatus;
	
	@OneToMany(mappedBy ="accounting")
	private Set<Payroll> payroll;

	public Accounting() {
	}

	public Long getAccountingId() {
		return accountingId;
	}

		
	public String getAccountingName() {
		return accountingName;
	}

	public void setAccountingName(String accountingName) {
		this.accountingName = accountingName;
	}

	public void setAccountingId(Long accountingId) {
		this.accountingId = accountingId;
	}

	public double getActualBudget() {
		return actualBudget;
	}

	public void setActualBudget(double actualBudget) {
		this.actualBudget = actualBudget;
	}

	public double getPredictiveBudget() {
		return predictiveBudget;
	}

	public void setPredictiveBudget(double predictiveBudget) {
		this.predictiveBudget = predictiveBudget;
	}

	public String getBudgetStatus() {
		return budgetStatus;
	}

	public void setBudgetStatus(String budgetStatus) {
		this.budgetStatus = budgetStatus;
	}

	public Set<Payroll> getPayroll() {
		return payroll;
	}

	public void setPayroll(Set<Payroll> payroll) {
		this.payroll = payroll;
	}
	
	
}

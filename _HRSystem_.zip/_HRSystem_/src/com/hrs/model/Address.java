package com.hrs.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name="tblAddress")
@XmlRootElement
public class Address implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(generator="generator")
	@GenericGenerator(name="generator",strategy="foreign", parameters=@Parameter(name="property", value = "employee"))
	private Long addressId;
	
	@Column(name="tblAddress_HouseNo")//@NotBlank @NotEmpty
	private String houseNo;
	
	@Column(name="tblAddress_StreetName")//@NotBlank @NotEmpty
	private String streetName;
	
	@Column(name="tblAddress_Suburb")//@NotBlank @NotEmpty
	private String suburb;
	
	@Column(name="tblAddress_CityTown")//@NotBlank @NotEmpty
	private String cityTown;
	
	@Column(name="tblAddress_PostalCode")//@Size(min=4, max = 4)@NotBlank @NotEmpty
	private int postalCode;
	
	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.EAGER)
	@PrimaryKeyJoinColumn(name="tblEmployee")
	private Employee employee;

	

	public Address() {
	}



	public Long getAddressId() {
		return addressId;
	}



	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}



	public String getHouseNo() {
		return houseNo;
	}



	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}



	public String getStreetName() {
		return streetName;
	}



	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}



	public String getSuburb() {
		return suburb;
	}



	public void setSuburb(String suburb) {
		this.suburb = suburb;
	}



	public String getCityTown() {
		return cityTown;
	}



	public void setCityTown(String cityTown) {
		this.cityTown = cityTown;
	}



	public int getPostalCode() {
		return postalCode;
	}



	public void setPostalCode(int postalCode) {
		this.postalCode = postalCode;
	}



	public Employee getEmployee() {
		return employee;
	}



	public void setEmployee(Employee employee) {
		this.employee = employee;
	}	

}

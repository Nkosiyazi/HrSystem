package com.hrs.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;



@Entity
@Table(name="tblAcademic")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@NamedQueries
({
	@NamedQuery(name="Academic.byId",query="from Academic  where academicId =?"),
	@NamedQuery(name="Academic.byList", query="from Academic")	
})
//@Cacheable
//@Cache(usage =CacheConcurrencyStrategy.READ_ONLY)
public class Academic implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long academicId;
	
	@Column(name="tblAcademic_Name")
	private String academicName;
	
	@Column(name="tblAcademic_InstitutionName")
	private String institutionName;
	
	@Column(name="tblAcademic_YearObtaineded")
	private Date yearObtained;
	
	@Column(name="tblAcademic_CV")
	private byte[] cv;
	
	@Column(name="tblAcademic_Certificate")
	private byte[] certificate;
	
	@ManyToOne
	@JoinColumn(name="tblEmpNumber")
	private Employee employee;
	
	
	public Long getAcademicId() {
		return academicId;
	}
	public void setAcademicId(Long academicId) {
		this.academicId = academicId;
	}
	public String getAcademicName() {
		return academicName;
	}
	public void setAcademicName(String academicName) {
		this.academicName = academicName;
	}
	public String getInstitutionName() {
		return institutionName;
	}
	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}
	public Date getYearObtaineded() {
		return yearObtained;
	}
	public void setYearObtained(Date yearObtained) {
		this.yearObtained = yearObtained;
	}
	public  byte[] getCv() {
		return cv;
	}
	public void setCv(byte[] cv) {
		this.cv = cv;
	}
	public byte[] getCertificate() {
		return certificate;
	}
	public void setCertificate(byte[] certificate) {
		this.certificate = certificate;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public Academic() {
	}
}

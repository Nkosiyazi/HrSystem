package com.hrs.model;



import java.io.Serializable;
import java.util.Date;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "tblTimesheetAttendance")

@NamedQueries
({
	@NamedQuery(name="findTimesheetAttendanceById",query="from TimesheetAttendance  where timesheetAttendanceId =:timesheetAttendanceId"),
	@NamedQuery(name="getTimesheetAttendanceList", query="from TimesheetAttendance")
	
})
@XmlRootElement
public class TimesheetAttendance implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4639650999049243803L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long timesheetAttendanceId;
	
	@NotNull
	@DecimalMin("0")
	@Column(name = "tblTimesheetAttendance_HoursWorkedPerDay")
	private int hoursWorkedPerDay;
	
	@NotNull
	@DecimalMin("0")
	@Column(name = "tblTimesheetAttendance_OvertimeHoursWorkedPerDay")
	private int overtimeHoursWorkedPerDay;
	
	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "tblTimesheetAttendance_StartofWorkTime")
	private Date startofWorkTime;
	
	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "tblTimesheetAttendance_EndofWorkTime")
	private Date endofWorkTime;
	
	@ManyToOne
	@JoinColumn(name="tblEmpNumber")
	private Employee employee;
	
	@ManyToOne
	@JoinColumn(name="payrollId")
	private Payroll payroll;

	public Long getTimesheetAttendanceId() {
		return timesheetAttendanceId;
	}

	public void setTimesheetAttendanceId(Long timesheetAttendanceId) {
		this.timesheetAttendanceId = timesheetAttendanceId;
	}

	public int getHoursWorkedPerDay() {
		return hoursWorkedPerDay;
	}

	public void setHoursWorkedPerDay(int hoursWorkedPerDay) {
		this.hoursWorkedPerDay = hoursWorkedPerDay;
	}

	public int getOvertimeHoursWorkedPerDay() {
		return overtimeHoursWorkedPerDay;
	}

	public void setOvertimeHoursWorkedPerDay(int overtimeHoursWorkedPerDay) {
		this.overtimeHoursWorkedPerDay = overtimeHoursWorkedPerDay;
	}

	public Date getStartofWorkTime() {
		return startofWorkTime;
	}

	public void setStartofWorkTime(Date startofWorkTime) {
		this.startofWorkTime = startofWorkTime;
	}

	public Date getEndofWorkTime() {
		return endofWorkTime;
	}

	public void setEndofWorkTime(Date endofWorkTime) {
		this.endofWorkTime = endofWorkTime;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Payroll getPayroll() {
		return payroll;
	}

	public void setPayroll(Payroll payroll) {
		this.payroll = payroll;
	}

	public TimesheetAttendance(int hoursWorkedPerDay,
			int overtimeHoursWorkedPerDay, Date startofWorkTime,
			Date endofWorkTime) {
		this.hoursWorkedPerDay = hoursWorkedPerDay;
		this.overtimeHoursWorkedPerDay = overtimeHoursWorkedPerDay;
		this.startofWorkTime = startofWorkTime;
		this.endofWorkTime = endofWorkTime;
	}

	public TimesheetAttendance(){
		// TODO Auto-generated constructor stub
	}
	
	
}

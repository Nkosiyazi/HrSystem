package com.hrs.dao;

import java.util.List;

import com.hrs.model.Grade;

public interface GradeDao {
	
	public Long saveGrade(Grade grade);
	public Long updateGrade(Long gradeId, Grade grade);
	public Grade getGrade(Long gradeId);
	public void deactivateGrade(Grade grade);
	public List<Grade> gradesList();

}

package com.hrs.dao;

import com.hrs.model.Address;

public interface AddressDao {

	public Long saveAddress(Address adress);
	public Long updateAddress(Long addressId, Address address);
	public Address searchAddress(Long addressId);
}

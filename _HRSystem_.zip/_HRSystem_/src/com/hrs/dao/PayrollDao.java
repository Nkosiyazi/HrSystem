package com.hrs.dao;

import java.util.List;

import com.hrs.model.Payroll;

public interface PayrollDao {

	Long savePayroll(Payroll payroll);
	Payroll getPayroll(String payrollName);
	Long updatePayroll(Payroll payroll);
	List<Payroll> getPayrollList();
}

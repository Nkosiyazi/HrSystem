package com.hrs.dao;

import java.util.List;

import com.hrs.model.Department;

public interface DepartmentDao {

	Long saveDepartment(Department department);
	Department getDepartment(Long departmentId);
	Long updateDepartment(Department department);
	List<Department> getDepartmentList();
}

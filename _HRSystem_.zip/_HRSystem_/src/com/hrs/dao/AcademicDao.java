package com.hrs.dao;

import com.hrs.model.Academic;

public interface AcademicDao {

	public Long saveAcademic(Academic academic);
	public Long updateAcademic(Long academicId,Academic academic);
	public Long removeAcademic(Long academicId);
}

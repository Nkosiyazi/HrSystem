package com.hrs.dao;

import java.util.List;

import com.hrs.model.Employee;

public interface EmployeeDoa {
public long registerEmployee(Employee employee);
public Long updateEmployee(Employee employee);
public Employee searchEmployee(Long empNumber);
public List<Employee> employeeList();


}

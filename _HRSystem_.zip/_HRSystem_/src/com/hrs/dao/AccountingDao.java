package com.hrs.dao;

import java.util.List;

import com.hrs.model.Accounting;

public interface AccountingDao {
	
	Long saveAccounting(Accounting accounting);	
	Accounting getAccounting(String accountingName);
	Long updateAccounting(Accounting accounting);
	List<Accounting> getAccountingList();

}

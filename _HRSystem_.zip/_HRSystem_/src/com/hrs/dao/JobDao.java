package com.hrs.dao;

import java.util.List;

import com.hrs.model.Job;

public interface JobDao {

	public Long saveJob(Job job);
	public Long updateJob(Job job);
	public Job searchJob(Long jobId);
	public List<Job> jobList();
}

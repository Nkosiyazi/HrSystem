package com.hrs.dao;

import java.util.List;

import com.hrs.model.Bank;

public interface BankDao {

	public Long saveBank(Bank bank);
	public List<Bank> bankList();
	public Bank getBank(Long bankId);
	
}

package com.hrs.dao;

import java.util.List;

import com.hrs.model.Training;

public interface TrainingDao {

	Long saveTraining(Training training);
	Training getTraining(String trainingName);
	Long updateTraining(Training training);
	List<Training> getTrainingList();
	
}

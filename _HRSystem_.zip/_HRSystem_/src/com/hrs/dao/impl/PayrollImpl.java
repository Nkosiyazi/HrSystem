package com.hrs.dao.impl;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.hrs.dao.PayrollDao;
import com.hrs.model.Employee;
import com.hrs.model.Leave;
import com.hrs.model.Payroll;
import com.hrs.model.SaleCommission;
import com.hrs.model.TimesheetAttendance;
import com.hrs.session.helper.SessionFactoryHelper;

public class PayrollImpl implements PayrollDao
{

	EmployeeDaoImpl empDao = null;
	Employee employee = null;
	List<Employee> employeeList = null;
	
	TimesheetAttendanceImpl timesheetDao = null;
	List<TimesheetAttendance> timesheetList = null;
	
	SaleCommissionImpl saleComDao = null;
	List<SaleCommission> commissions = null;
	
	LinkedList<Employee> employeeSalaryList = new LinkedList<Employee>();
	
	List<Leave> leaveList = null;
	LeaveDaoImpl leaveDaoImpl =null;
	Session session = null;
	Date currentDate = null;
	
	@Override
	public Long savePayroll(Payroll payroll) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		session.save(payroll);
		
		session.getTransaction().commit();
		
		return payroll.getPayrollId();
	}

	@Override
	public Payroll getPayroll(String payrollName) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		Query query =  session.getNamedQuery("findPayrollByName");
		
		query.setString("payrollName", payrollName);
				
		return (Payroll)query.uniqueResult();
	}

	@Override
	public Long updatePayroll(Payroll payroll) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		session.update(payroll);
		
		session.getTransaction().commit();
		
		return payroll.getPayrollId();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Payroll> getPayrollList() {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		Query queryResult = session.getNamedQuery("getPayrollList");
		
		return queryResult.list();
	}

	
	public LinkedList<Employee> calculateSalaries(){
		
		
		empDao = new EmployeeDaoImpl();
		employeeList = empDao.employeeList();
		
		
		double salary = 0.0,netSalary = 0.0,uif=0.01,pensionFund = 0.051;
		double uifAmount =0.0, pensionFundAmount = 0.0, grossSalary = 0.0, commissionAmount=0.0;
		for (Employee employee : employeeList) 
		{
			
			if (employee.getJob().getJobType().equalsIgnoreCase("salaried")) 
			{
				
				salary = employee.getJob().getGrade().getSalary();
				netSalary = employeeDeductions(employee.getEmpNumber(), salary);
				
				uifAmount = employee.getJob().getGrade().getSalary() *uif;
				pensionFundAmount= employee.getJob().getGrade().getSalary() *pensionFund;
				
				
				
				employee.getJob().getGrade().setUifDeduction(uifAmount);
				employee.getJob().getGrade().setPensionDeduction(pensionFundAmount);
				employee.getJob().getGrade().setNetSalary(netSalary);
				employeeSalaryList.add(employee);
			   
				
			} else if (employee.getJob().getJobType().equalsIgnoreCase("salaryCommission")) 
			{
				grossSalary = employee.getJob().getGrade().getSalary();
				salary = salaryCommissionEmployees(employee.getEmpNumber());
                netSalary = employeeDeductions(employee.getEmpNumber(), grossSalary);
                
                uifAmount = employee.getJob().getGrade().getSalary() *uif;
				pensionFundAmount= employee.getJob().getGrade().getSalary() *pensionFund;
				
				
				employee.getJob().getGrade().setCommissionAmount(salary);
				employee.getJob().getGrade().setUifDeduction(uifAmount);
				employee.getJob().getGrade().setPensionDeduction(pensionFundAmount);
				
				employee.getJob().getGrade().setNetSalary(netSalary +salary);
				employeeSalaryList.add(employee);
				
			} 
			else if (employee.getJob().getJobType().equalsIgnoreCase("commission")) 
			{
				
			salary = commissionEmployees(employee.getEmpNumber());
			
			netSalary = employeeDeductions(employee.getEmpNumber(), salary);
			
			uifAmount = employee.getJob().getGrade().getSalary() *uif;
			pensionFundAmount= employee.getJob().getGrade().getSalary() *pensionFund;
			
			
			
			employee.getJob().getGrade().setUifDeduction(uifAmount);
			employee.getJob().getGrade().setPensionDeduction(pensionFundAmount);
			
			employee.getJob().getGrade().setNetSalary(netSalary);
			employeeSalaryList.add(employee);
				
			} else if (employee.getJob().getJobType().equalsIgnoreCase("hourly")) 
			{
				
				salary= hourlyEmployees(employee.getEmpNumber());
                netSalary = employeeDeductions(employee.getEmpNumber(), salary);
                
                uifAmount = employee.getJob().getGrade().getSalary() *uif;
				pensionFundAmount= employee.getJob().getGrade().getSalary() *pensionFund;
				
				
				
				employee.getJob().getGrade().setUifDeduction(uifAmount);
				employee.getJob().getGrade().setPensionDeduction(pensionFundAmount);
				
				employee.getJob().getGrade().setNetSalary(netSalary);
			    employeeSalaryList.add(employee);
			}
		}
		return employeeSalaryList;
		
	}
	

	
	private double salaryCommissionEmployees(Long empNumber){
		
		
		currentDate = new Date();
		saleComDao = new SaleCommissionImpl();
		commissions = saleComDao.getSaleCommissionList();
		double basicSalary = 0,totalSalesAmount = 0 , salaryCommission= 0.0, commisionRate = 0.10;
		
	    for(SaleCommission commission: commissions)
	    {
	    	if(empNumber.equals(commission.getEmployee().getEmpNumber()))
	    	{
	    		if(currentDate.getYear()== commission.getDate().getYear()&&
	    				currentDate.getMonth()==commission.getDate().getMonth())
	    		{
	    		   totalSalesAmount += commission.getSalesAmount();
	    		   basicSalary = commission.getEmployee().getJob().getGrade().getSalary();
	    		   
	    		}
	    	}
	    	
	    }
	    salaryCommission = basicSalary*commisionRate;
	    return salaryCommission;
	}
	private double commissionEmployees(Long empNumber){
		
		currentDate = new Date();
		saleComDao = new SaleCommissionImpl();
		commissions = saleComDao.getSaleCommissionList();
		double totalSalesAmount = 0.0 , salaryCommission= 0.0;
	    
		for(SaleCommission commission: commissions)
	    {
	    	if(empNumber.equals(commission.getEmployee().getEmpNumber()))
	    	{
	    		//check for current month
	    		if(currentDate.getYear()== commission.getDate().getYear()&&
						currentDate.getMonth()==commission.getDate().getMonth())
	    		{
	    		   totalSalesAmount += commission.getSalesAmount();
	    		}
	    		
	    	}
	    }
		if(totalSalesAmount ==100 && totalSalesAmount <=500)
		{
			salaryCommission = totalSalesAmount*0.05;
		}
		else if(totalSalesAmount >500 &&totalSalesAmount <=1000)
		{
			salaryCommission = totalSalesAmount * 0.08;
		}
		else if(totalSalesAmount >1000 && totalSalesAmount <=2000)
		{
			salaryCommission = totalSalesAmount * 0.10;
		}
		else if(totalSalesAmount >2000 && totalSalesAmount <=3500)
		{
			salaryCommission = totalSalesAmount * 0.16;
		}
		else if(totalSalesAmount >3500 && totalSalesAmount <=5000)
		{
			salaryCommission = totalSalesAmount * 0.20;
		}
		else if(totalSalesAmount >10000 && totalSalesAmount< 20000)
		{
			salaryCommission = totalSalesAmount * 0.28;
		}
		else if (totalSalesAmount > 20000)
		{
			salaryCommission = totalSalesAmount*0.35;
		}
		return salaryCommission;
	}
	private double hourlyEmployees(Long empNumber)
	{
		double hourlyPay = 0;
		double hourlyRate = 75.50;
		int totalHours = 0;
		
		totalHours = calcMonthlyHours(empNumber);
		
		hourlyPay = totalHours*hourlyRate;
		
		return hourlyPay;
	}
	
	private int calcMonthlyHours(Long empNumber)
	{
        currentDate = new Date();
		timesheetDao =new TimesheetAttendanceImpl();
		
		timesheetList=timesheetDao.getTimesheetAttendanceList();
		int monthlyHours = 0;
		for (TimesheetAttendance timesheet : timesheetList) 
		{
			
			if (empNumber.equals(timesheet.getEmployee().getEmpNumber()))
			{
				//Check for dates first
				if(currentDate.getYear()== timesheet.getEndofWorkTime().getYear()&&
						currentDate.getMonth()==timesheet.getEndofWorkTime().getMonth())
				{
				   monthlyHours += timesheet.getHoursWorkedPerDay();
				}
			}
		}
		
		return monthlyHours;
	}

    private boolean isAbsentKnown(Long empNumber)
    {
    	currentDate = new Date();
    	
    	leaveDaoImpl = new LeaveDaoImpl();
		leaveList = leaveDaoImpl.getLeaveList();
		boolean isLeaveApproved  = false;
		for(Leave leave: leaveList)
		{
			if(empNumber.equals(leave.getEmployee().getEmpNumber()))
			{
				//use date to check for current month
				if(currentDate.getYear()== leave.getLeaveStartDate().getMonth()&&
						currentDate.getYear()==leave.getLeaveStartDate().getMonth())
				{
				  if(leave.getDepartmentManagerApproval().equalsIgnoreCase("aproved") && leave.getDepartmentManagerApproval().equals("aproved"))
				   {
					 isLeaveApproved = true;
				   }
				   else{
					  isLeaveApproved = false;
				  }
				}
				else{
					isLeaveApproved = false;
				}
			}
		}
		return isLeaveApproved;
    }
    public void printSalaries()
    { 
    	double salaries = 0.0;
    	
    	calculateSalaries();
    	System.out.println("Name\t\t\tNet Salary\t\tUIF\t\tPension");
    	for(Employee emp : employeeSalaryList)
    	{
    		salaries += emp.getJob().getGrade().getSalary();
    		System.out.println(emp.getFirstName()+ "\t\t\t"+ emp.getJob().getGrade().getSalary()+"\t\t\t"+emp.getJob().getGrade().getUifDeduction()+"\t\t"+emp.getJob().getGrade().getPensionDeduction() );
    	}
    	System.out.println("");
    	System.out.println("");
    	System.out.println("Monthly salaries for all employees is " + salaries);
    }
    private double employeeDeductions(Long empNumber,double grossSalary)
    {
    	double netSalary =0.0, uif=0.01,pensionFund = 0.051; 
    	
    	employee = empDao.searchEmployee(empNumber);
    	if(employee.getJob().getJobType().equalsIgnoreCase("salaried"))
    	{
    		netSalary = grossSalary-((grossSalary*uif)+(grossSalary*pensionFund));
    	}
    	else if (employee.getJob().getJobType().equalsIgnoreCase("salaryCommission"))
    	{
    		netSalary = grossSalary-((grossSalary*uif)+(grossSalary*pensionFund));
    	}
    	else if (employee.getJob().getJobType().equalsIgnoreCase("commission"))
    	{
    		netSalary = grossSalary-(grossSalary*uif);
    	}
    	else if (employee.getJob().getJobType().equalsIgnoreCase("hourly"))
    	{
    		netSalary = grossSalary-(grossSalary*uif);
    	}
    	
    	return netSalary;
    }
}



package com.hrs.dao.impl;

import java.util.List;





import org.hibernate.Query;
import org.hibernate.Session;

import com.hrs.dao.AccountingDao;
import com.hrs.model.Accounting;
import com.hrs.session.helper.SessionFactoryHelper;

public class AccountingImpl implements AccountingDao
{

	Session session = null;
	
	@Override
	public Long saveAccounting(Accounting accounting) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		session.save(accounting);
		
		session.getTransaction().commit();
		
		return accounting.getAccountingId();
	}

	@Override
	public Accounting getAccounting(String accountingName) {
	
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		Query query =  session.getNamedQuery("findAccountingByName");
		
		query.setString("accountingName", accountingName);
				
		return (Accounting)query.uniqueResult();
	}

	@Override
	public Long updateAccounting(Accounting accounting) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		session.update(accounting);
		
		session.getTransaction().commit();
		
		return accounting.getAccountingId();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Accounting> getAccountingList() {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
				
		Query queryResult = session.getNamedQuery("getAccoutingList");
		
		return queryResult.list();				
	}

}

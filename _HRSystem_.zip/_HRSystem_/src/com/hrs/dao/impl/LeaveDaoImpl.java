package com.hrs.dao.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.hrs.dao.LeaveDao;
import com.hrs.model.Leave;
import com.hrs.session.helper.SessionFactoryHelper;

public class LeaveDaoImpl implements LeaveDao
{

	Session session = null;
		
	@Override
	public Long saveLeave(Leave leave) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		session.save(leave);
		
		session.getTransaction().commit();
		
		return leave.getLeaveId();

	}

	@Override
	public Leave getLeave(Long leaveId) {

		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		Query query =  session.getNamedQuery("findLeaveById");
		
		query.setLong("leaveId", leaveId);
				
		return (Leave)query.uniqueResult();
	}

	@Override
	public Long updateLeave(Leave leave) {

		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		session.update(leave);
		
		session.getTransaction().commit();
		
		return leave.getLeaveId();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Leave> getLeaveList() {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		Query queryResult = session.getNamedQuery("getLeaveList");
		
		return queryResult.list();	
	}


	@SuppressWarnings("static-access")
	@Override
	public int calculateNumberOfDays(Date start, Date end) {

		Calendar calendarStart = Calendar.getInstance();
		Calendar calendarEnd = Calendar.getInstance();
		
		calendarStart.setTime(start);
		calendarEnd.setTime(end);
		
		int days = 0;
		int differentMonthDays = 0;
		
		if(calendarEnd.get(calendarEnd.MONTH) > calendarStart.get(calendarStart.MONTH))
		{			
			differentMonthDays = calendarStart.getActualMaximum(calendarStart.DATE) - calendarStart.get(calendarStart.DATE);
			
			days = (calendarEnd.get(calendarEnd.DATE) + differentMonthDays);	
		}
		else if(calendarEnd.get(calendarEnd.MONTH) == calendarStart.get(calendarStart.MONTH))
		{
			days = (calendarEnd.get(calendarEnd.DATE) - calendarStart.get(calendarStart.DATE));			
		}
		
		if(((calendarStart.get(calendarStart.YEAR) == calendarEnd.get(calendarEnd.YEAR)) &&
			(calendarStart.get(calendarStart.MONTH) == calendarEnd.get(calendarEnd.MONTH)))	&&
			(calendarStart.get(calendarStart.DATE) == calendarEnd.get(calendarEnd.DATE)))
		{
			days = 1;
		}
		
		return days;
	}

	@Override
	public int validateLeaveDays(int requestedLeaveDays,int actualDaysLeft) {
	
		int leaveDays = 0;
		
		if(actualDaysLeft > 0)
		{
			leaveDays = actualDaysLeft - requestedLeaveDays;
		}
		else if(requestedLeaveDays > actualDaysLeft)
		{
			leaveDays = -1;
		}
		
		
		return leaveDays;
	}

	@Override
	public String leaveStatus(int validatedLeaveDays) {
		
		String leaveStatus = "";
		
		if(validatedLeaveDays == -1)
		{
			leaveStatus = "Denied - Verify leave days requested";
		}
		else if(validatedLeaveDays == 0)
		{
			leaveStatus = "No Leave days available";
		}
		else if(validatedLeaveDays > 0)
		{
			leaveStatus = "Approved ";
		}
		
		return leaveStatus;
	}

}

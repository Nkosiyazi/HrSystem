package com.hrs.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.hrs.dao.DepartmentDao;
import com.hrs.model.Department;
import com.hrs.session.helper.SessionFactoryHelper;

public class DepartmentImpl implements DepartmentDao
{

	
	Session session = null;
	@Override
	public Long saveDepartment(Department department) {

		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();

		session.beginTransaction();
		session.save(department);
		session.getTransaction().commit();
		session.close();
		return department.getDepartmentId();
	}

	@Override
	public Department getDepartment(Long departmentId) {

		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();

		session.beginTransaction();
		
		Query query = session.getNamedQuery("findDepartmentById");
		query.setLong(0, departmentId);
		Department department = (Department) query.uniqueResult();
		session.close();
		return department;
	}

	@Override
	public Long updateDepartment(Department department) {
		
		session = SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		session.saveOrUpdate(department);
		session.getTransaction().commit();
		session.close();
		return department.getDepartmentId();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Department> getDepartmentList() {

		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		Query query = session.getNamedQuery("allDepartment");
		List<Department> departments = query.list();
		session.close();
		return departments;
	}

}

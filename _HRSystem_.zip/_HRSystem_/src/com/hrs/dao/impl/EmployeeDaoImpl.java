package com.hrs.dao.impl;

import java.rmi.RemoteException;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.hrs.dao.EmployeeDoa;
import com.hrs.model.Employee;
import com.hrs.session.helper.SessionFactoryHelper;
import com.xml_fx.services.SAIDValidator.SAIDValidatorSoapProxy;
import com.xml_fx.services.SAIDValidator.said_xsd.SaidType;

public class EmployeeDaoImpl implements EmployeeDoa{
	
	
	Session session = null;
	
	@Override
	public long registerEmployee(Employee employee) {
        SAIDValidatorSoapProxy proxy = new SAIDValidatorSoapProxy();
		
//		try {
//			SaidType saidType = proxy.validateIdString("", employee.getIdentityNumber());
//			if(saidType.isValid()==true)
//			{
				session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
				
				session.beginTransaction();
				session.save(employee);
				session.getTransaction().commit();
				session.close();
//			}
//			else {
//				
//			}
			
//		} catch (RemoteException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//
//		}
		return employee.getEmpNumber();

	}

	@Override
	public Employee searchEmployee(Long empNumber) {
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("Employee.byId");
		query.setLong(0, empNumber);
		Employee employee = (Employee) query.uniqueResult();
		session.close();
		return employee;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> employeeList() {
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		
		Query query = session.getNamedQuery("Employee.byList");
		List<Employee> employees = query.list();
		session.close();
		return employees;
	}

	@Override
	public Long updateEmployee(Employee employee) {
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();

		
		session.beginTransaction();
		session.saveOrUpdate(employee);
		session.getTransaction().commit();
		session.close();
		return employee.getEmpNumber();
	}
	
	public Employee logIn(String email) {
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("Employee.byEmail");
		query.setString("empNumber", email);
		Employee employee = (Employee) query.uniqueResult();
		session.close();
		return employee;
	}

}

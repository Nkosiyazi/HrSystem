package com.hrs.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.hrs.dao.SaleCommissionDao;
import com.hrs.model.SaleCommission;
import com.hrs.session.helper.SessionFactoryHelper;

public class SaleCommissionImpl implements SaleCommissionDao
{
	Session session = null;
	
	@Override
	public Long saveSaleCommission(SaleCommission saleCommission) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		session.save(saleCommission);
		
		session.getTransaction().commit();
		
		return saleCommission.getCommissionId();
	}

	@Override
	public SaleCommission getSaleCommission(Long saleCommissionId) {

		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		Query query =  session.getNamedQuery("findSaleCommissionById");
		
		query.setLong("saleCommissionId", saleCommissionId);
				
		return (SaleCommission)query.uniqueResult();
	}

	@Override
	public Long updateSaleCommission(SaleCommission saleCommission) {

		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		session.update(saleCommission);
		
		session.getTransaction().commit();
		
		return saleCommission.getCommissionId();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SaleCommission> getSaleCommissionList() {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		Query queryResult = session.getNamedQuery("getSaleCommissionList");
		
		return queryResult.list();	
	}

}

package com.hrs.dao.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.hrs.dao.TimesheetAttendanceDao;
import com.hrs.model.TimesheetAttendance;
import com.hrs.session.helper.SessionFactoryHelper;

public class TimesheetAttendanceImpl implements TimesheetAttendanceDao
{

	Session session = null;
	
	Calendar startTime = Calendar.getInstance();
	Calendar endTime = Calendar.getInstance();
	
	@Override
	public Long saveTimesheetAttendance(TimesheetAttendance timesheetAttendance) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		session.save(timesheetAttendance);
		
		session.getTransaction().commit();
		
		return timesheetAttendance.getTimesheetAttendanceId();
	}

	@Override
	public TimesheetAttendance getTimesheetAttendance(Long timesheetAttendanceId) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		Query query =  session.getNamedQuery("findTimesheetAttendanceById");
		
		query.setLong("timesheetAttendanceId", timesheetAttendanceId);
				
		return (TimesheetAttendance)query.uniqueResult();
	}

	@Override
	public Long updateTimesheetAttendance(
			TimesheetAttendance timesheetAttendance) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		session.update(timesheetAttendance);
		
		session.getTransaction().commit();
		
		return timesheetAttendance.getTimesheetAttendanceId();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TimesheetAttendance> getTimesheetAttendanceList() {
		

		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
				
		Query queryResult = session.getNamedQuery("getTimesheetAttendanceList");
		
		return queryResult.list();	
	}

	@SuppressWarnings("static-access")
	@Override
	public int calculateNormalHoursWorked(Date startDateHour, Date endDateHour) {
		
		int totalHoursWorked = 0;
		int startHour = 0;
		int endHour = 0;
						
		startTime.setTime(startDateHour);
		endTime.setTime(endDateHour);
				
		startHour = (startTime.getActualMaximum(startTime.HOUR) +1) - startTime.get(startTime.HOUR);
		endHour =  endTime.get(endTime.HOUR);
						
		totalHoursWorked = endHour + startHour;
				
		return totalHoursWorked;
	}

	@SuppressWarnings("static-access")
	@Override
	public int addNormalMinutesWorked(Date startingMinute, Date endingMinute) {
		
		int totalMinutesWorked = 0;
				
		startTime.setTime(startingMinute);
		endTime.setTime(endingMinute);
		
		totalMinutesWorked = startTime.get(startTime.MINUTE) + endTime.get(endTime.MINUTE);
		
		return totalMinutesWorked;
	}

	@Override
	public int minusNormalHours(int totalHours) {
		
		int normalHours = 9;
		int actualHoursWorked = 0;
				
		if((totalHours < normalHours) || (totalHours == normalHours))
		{
			actualHoursWorked = totalHours;
		}	
		return actualHoursWorked;
	}

	@Override
	public int minusOverTimeHours(int totalHours) {

		int normalHours = 9;
		int overtimeWorked = 0;
		
		if(totalHours > normalHours)
		{
			overtimeWorked = totalHours - normalHours;
		}
				
		return overtimeWorked;
	}

	@Override
	public int calculateMinutesToHoursWoked(int totalMinutes) {

		int minuteToHours = 0;
		int standardMinutes = 60;
		
		if((totalMinutes > standardMinutes)||(totalMinutes == standardMinutes))
		{
			minuteToHours = totalMinutes/standardMinutes;
		}
		
		return minuteToHours;
	}
	
}

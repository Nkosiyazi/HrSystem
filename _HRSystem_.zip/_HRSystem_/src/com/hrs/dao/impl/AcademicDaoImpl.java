package com.hrs.dao.impl;

import org.hibernate.Session;

import com.hrs.dao.AcademicDao;
import com.hrs.model.Academic;
import com.hrs.session.helper.SessionFactoryHelper;


public class AcademicDaoImpl implements AcademicDao{

	Session session= null;
	
	@Override
	public Long saveAcademic(Academic academic) {
		session = SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		session.save(academic);
		session.getTransaction().commit();
		session.close();
		return academic.getAcademicId();
	}

	@Override
	public Long updateAcademic(Long academicId, Academic academic) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Long removeAcademic(Long academicId) {
		
		session = SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
//		Academic 
//		session.delete(academicId);
//		session.getTransaction().commit();
//		session.close();
		return null;
	}

}

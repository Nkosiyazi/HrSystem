package com.hrs.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.hrs.dao.JobDao;
import com.hrs.model.Job;
import com.hrs.session.helper.SessionFactoryHelper;

public class JobDaoImpl implements JobDao{
	
	
	 
	Session session = null;
	@Override
	public Long saveJob(Job job) {
		
		
		session = (Session) SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		session.save(job);
		session.getTransaction().commit();
		session.close();
		return job.getJobId();
	}

	@Override
	public Long updateJob(Job job) {
		

		session = SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		session.saveOrUpdate(job);
		session.getTransaction().commit();
		session.close();
		return job.getJobId();
	}

	@Override
	public Job searchJob(Long jobId) {
		session= SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		Query query  = session.getNamedQuery("Job.byId");
		query.setLong("jobId", jobId);
		Job job = (Job) query.uniqueResult();
		session.close();
		return job;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Job> jobList() {
		session= SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("Job.byList");
		List<Job> jobList = query.list();
		session.close();	
		return jobList;
	}

}

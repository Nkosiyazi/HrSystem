package com.hrs.dao.impl;

import java.util.List;




import org.hibernate.Query;
import org.hibernate.Session;

import com.hrs.dao.GradeDao;
import com.hrs.model.Department;
import com.hrs.model.Grade;
import com.hrs.session.helper.SessionFactoryHelper;

public class GradeDaoImpl implements GradeDao {

	
	Session session = null;
	@Override
	public Long saveGrade(Grade grade) {
		
	    session = SessionFactoryHelper.getSessionFactory().openSession();
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		session.save(grade);
		session.getTransaction().commit();
		session.close();
		return grade.getGradeId();
	}

	@Override
	public Long updateGrade(Long gradeId, Grade grade) {

		session = SessionFactoryHelper.getSessionFactory().openSession();
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		session.get(Grade.class, gradeId);
		return grade.getGradeId();
	}

	@Override
	public Grade getGrade(Long gradeId) {
		
		session= SessionFactoryHelper.getSessionFactory().openSession();
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		
		Query query =session.getNamedQuery("SearchGrade");
		query.setLong(0, gradeId);
		Grade grade = (Grade) query.uniqueResult();
		session.close();
		return grade;
	}

	@Override
	public void deactivateGrade(Grade grade) {

		session= SessionFactoryHelper.getSessionFactory().openSession();
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		session.delete(grade);                                      
	
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Grade> gradesList() {
        
        session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		Query query = session.getNamedQuery("ListGrades");
		List<Grade> gradeList = query.list();
		session.close();
		return gradeList;
		
	}

}

package com.hrs.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.hrs.dao.TrainingDao;
import com.hrs.model.Training;
import com.hrs.session.helper.SessionFactoryHelper;

public class TrainingImpl implements TrainingDao
{

	Session session = null;
	
	@Override
	public Long saveTraining(Training training) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		session.save(training);
		
		session.getTransaction().commit();
		
		return training.getTrainingId();
	}

	@Override
	public Training getTraining(String trainingName) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		Query query =  session.getNamedQuery("findTrainingByName");
		
		query.setString("trainingName", trainingName);
				
		return (Training)query.uniqueResult();
	}

	@Override
	public Long updateTraining(Training training) {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		session.update(training);
		
		session.getTransaction().commit();
		
		return training.getTrainingId();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Training> getTrainingList() {
		
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		
		Query queryResult = session.getNamedQuery("getTrainingList");
		
		return queryResult.list();
	}

}

package com.hrs.dao.impl;

import org.hibernate.Session;

import com.hrs.dao.AddressDao;
import com.hrs.model.Address;
import com.hrs.session.helper.SessionFactoryHelper;

public class AddressDaoImpl implements AddressDao {

	Session session = null;
	
	@Override
	public Long saveAddress(Address adress) {
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		session.save(adress);
		session.getTransaction().commit();
		session.close();
		return adress.getAddressId();
	}

	@Override
	public Long updateAddress(Long addressId, Address address) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Address searchAddress(Long addressId) {
		// TODO Auto-generated method stub
		return null;
	}

}

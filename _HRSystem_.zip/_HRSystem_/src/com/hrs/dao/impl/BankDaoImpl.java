package com.hrs.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.hrs.dao.BankDao;
import com.hrs.model.Bank;
import com.hrs.session.helper.SessionFactoryHelper;

public class BankDaoImpl implements BankDao{
	
	Session session = null;
	@Override
	public Long saveBank(Bank bank) {
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
			session.beginTransaction();
			session.save(bank);
			session.getTransaction().commit();
			session.close();
			return bank.getBankId();
	}

	@Override
	public List<Bank> bankList() {
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("Bank.byList");
		query.setCacheable(true);
		@SuppressWarnings("unchecked")
		List<Bank> banks= query.list();
		session.clear();
		return banks;
	}

	@Override
	public Bank getBank(Long bankId) {
		session = (Session)SessionFactoryHelper.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("Bank.byId");
		query.setLong(0, bankId);
		Bank bank = (Bank) query.uniqueResult();
		session.close();
		return bank;
	}

}

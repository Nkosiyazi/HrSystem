$(document).ready(function(){
	 
function academicViewModel(){
	

	     var self = this;
	       
	       self.academicName = ko.observable();
	       self.institutionName = ko.observable();
	       self.yearObtained = ko.observable();
	       self.cv = ko.observable();
	       self.certificate =ko.observable();
	       
	       var academicObject =
	       {	    	
	    		academicName : self.academicName,
	    	    institutionName : self.institutionName,
	    	    yearObtained:self.yearObtained ,
	    	    cv: self.cv,
	    	    certificate :self.certificate	    	       
	       };
	       
	       
	       self.saveEmployee = function()
			{
					
		
				$.ajax({

							data: ko.toJSON(academicObject),
							type:'POST',
							url:'http://localhost:8080/HRSystem/hrs/academicController/saveEmployee',
							contentType: 'application/json',
							dataType:"json",

							success: function(data)
									{
										console.log(data);
									
										alert("Record Added Successfully");
										console.log(data);
									},
							error: function (data, status)
									{
										alert(data.firstname+"Error Occured" + status);
									}
					});
			};
	       
	       
	};

	ko.applyBindings(new academicModelView());

});
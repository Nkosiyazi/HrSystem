$(document).ready(function()
		{
			
			function HrsViewModel()
			{
			
				
			};
			
			ko.applyBindings(new HrsViewModel());	
	
		});
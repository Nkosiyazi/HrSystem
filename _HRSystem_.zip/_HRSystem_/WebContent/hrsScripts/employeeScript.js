function alertFilename()
		{
			//var theFile = document.getElementById('theFile').files[0];
			
			var reader = new FileReader();
			
			
			
			
			
			//var filename = theFile.split('\\').pop();
			
			//var filename = theFile.replace("\\","/");
			
			//var filename = theFile.replace(/.*(\/|\\)/,'');
			
			alert(theFile)
		};
		
$('#picButton').click
	(
			function(e)
		{
				$.ajax
				({
					url:'http://localhost:8080/HRSystem/hrs/academicController/upload',
					type:'POST',
					data: new FormData(this),
					processData: false,
					contentType: 'multipart/form-data',
					
					success: function(data)
							{
								alert("GOOD STUFF")
							},
				    error: function()
				    		{
				    	
				    		}
				});
				
				e.preventDefault();
		});		
		
$(document).ready(function(){
	
     var employeeModelView = function()
     {
    	 		self = this;
    	 		
    	 		self.firstName = ko.observable();
    	 		self.middleName = ko.observable();
    	 		self.lastName = ko.observable();
    	 		self.identityNumber= ko.observable();
    	 		self.title = ko.observable();
    	 		self.gender = ko.observable();
    	 		self.dateOfBirth = ko.observable();
    	 		self.email = ko.observable();
    	 		self.maritalStatus = ko.observable();
    	 		self.ethnicGroup = ko.observable();
    	 		
    	 		self.job = ko.observable();
    	 		
    	 		self.houseNo = ko.observable();
	 			self.streetName = ko.observable();
	 			self.suburb = ko.observable();
	 			self.cityTown =ko.observable();
	 			self.postalCode = ko.observable();
	 			
	 			self.bankName = ko.observable();
	 			self.accountNumber = ko.observable();
	 			self.branchName = ko.observable();
	 			self.accountType = ko.observable();
	 			self.branchCode = ko.observable()
    	 		
    	 		self.address = ko.observable();
    	 		self.bank = ko.observable();
	 			
    	 		self.academicName = ko.observable();
 		       self.institutionName = ko.observable();
 		       self.yearObtained = ko.observable();
 		       self.cv = ko.observable();
 		       self.certificateUrl =ko.observable();
    	 
    	 		var addressBook =
    	 		{
    	 			houseNo : self.houseNo,
    	 			streetName : self.streetName,
    	 			suburb : self.suburb,
    	 			cityTown :self.cityTown,
    	 			postalCode : self.postalCode,
    	 			employee:self.employeeObject
    	 			    	 			
    	 		};

    	 		   
    	 		var bank={
    	 				bankName:self.bankName,
    	 				accountNumber:self.accountNumber,
    	 				branchName:self.branchName,
    	 				accountType:self.accountType,
    	 				branchCode:self.branchCode,
    	 				employee:self.employeeObject
    	 		};
    	 		
    	 		 
    		       
    		       var academicObject =
    		       {	    	
    		    		academicName : self.academicName,
    		    	    institutionName : self.institutionName,
    		    	    yearObtained:self.yearObtained ,
    		    	    cv: self.cv,
    		    	    certificateUrl :self.certificateUrl	    	       
    		       };
    		       
    		       
    		       
    		       self.jobList = ko.observableArray([]);
					
	    	 		$.getJSON('http://localhost:8080/HRSystem/hrs/JobController/jobList',null,function(jobData,status,xhr)
	    	 					{
					
	    	 						$.each(jobData,function(index,value)
	    	 							{
	    	 								self.jobList.push(value);
	    	 							});

	    	 					});                                                                                                                                                                                                                                    
		            
		
	    	 		self.departList = ko.observableArray([]);
		
	    	 		$.getJSON('http://localhost:8080/HRSystem/hrs/DepartmentController/departmentList',null,function(departmentData,status,xhr)
	    	 					{
			
	    	 						$.each(departmentData,function(index,value)
	    	 							{
	    	 								self.departList.push(value);
	    	 							});



	    	 					});
    	 		
    	 		
	
	 			var employeeObject ={

    	 				firstName:self.firstName,
    	 				middleName:self.middleName,
    	 				lastName:self.lastName,
    	 				identityNumber:self.identityNumber,
    	 				title:self.title,
    	 				gender:self.gender,
    	 				dateOfBirth:self.dateOfBirth,
    	 				email:self.email,
    	 				maritalStatus:self.maritalStatus,
    	 				ethnicGroup:self.ethnicGroup,
    	 				job:self.job,
    	 				bank:bank,
    	 				address:addressBook
    	 				
    	 		};

		 		
    	 			 
    	 		self.employeeObject = ko.observable();
	   
    	 		self.saveEmployee = function()
    	 					{
    	 							
    	 				
    	 						$.ajax({
	    	    
    	 									data: ko.toJSON(employeeObject),
    	 									type:'POST',
    	 									url:'http://localhost:8080/HRSystem/hrs/employeeController/addEmployee',
    	 									contentType: 'application/json',
    	 									dataType:"json",
	         
    	 									success: function(data)
    	 											{
    	 												console.log(data);
    	 											
    	 												alert("Record Added Successfully");
    	 												console.log(data);
    	 											},
    	 									error: function (data, status)
    	 											{
    	 												alert(data.firstname+"Error Occured" + status);
    	 											}
    	 							});
    	 					};
    	 					
    	 					

     };
		  ko.applyBindings(new employeeModelView()); 
});
	 
function jobViewModel(){
	
	this.jobTitle = ko.observable("");
	this.jobLevel = ko.observable("");
	this.jobLocation = ko.observable("");
	this.jobCategory = ko.observable("");
	this.noOfPositions = ko.observable("");
	this.jobType = ko.observable("");
	this.jobDescription = ko.observable("");
	this.probitionPeriod = ko.observable("");
	this.startDate = ko.observable("");
	this.endDate = ko.observable("");
	
	var jobObject = {
			jobTitle: jobTitler,
			jobLevel:jobLevel,
			jobLocation:jobLocation,
			jobCategory:jobCategory,
			noOfPositions:noOfPositions,
			jobDescription:jobDescription,
			probitionPeriod:probitionPeriod,
			startDate:startDate
		
		};
		
	self.saveEmployee = function(){
	   
	    $.ajax({
	    	    data: ko.toJSON(jobObject),
	            type:'POST',
	            url:'http://localhost:8080/HRSystem/hrs/JobController/saveJob',
	            contentType: 'application/json',
	            dataType:"json",
	         success: function(data){
	            console.log(data);
	            alert(data.address);
	            alert("Record Added Successfully");
	            console.log(data);
	            },
	         error: function (data, status)
	         {
	             alert("Failed" + status);
	         }
	    });
	  };
		
	};
	
ko.applyBindings(new jobViewModel());


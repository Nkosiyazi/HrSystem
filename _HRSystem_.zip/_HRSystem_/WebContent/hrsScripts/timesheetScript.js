$(document).ready(function(){
	
	var timesheetModel = function(){
		var self = this;
		self.employee = ko.observable();
		self.startofWorkTime = ko.observable();
		self.endofWorkTime = ko.observable();
		
		var timesheetObject ={
				employee:self.employee,
				startofWorkTime:self.startofWorkTime,
				endofWorkTime:self.endofWorkTime
		};
		
		  self.employeeList = ko.observableArray([]);
        
   		/*$.getJSON('http://localhost:8080/HRSystem/hrs/employeeController/employeeList',null,function(employeeData,status,xhr){
   			$.each(employeeData,function(index,value){
   				self.employeeList.push(value);
   			});
   		});*/
		self.saveTimesheet = function(){
			
			$.ajax({
				data:ko.toJSON(timesheetObject),
				type:'POST',
				url:'http://localhost:8080/HRSystem/hrs/TimesheetController/SaveAttendance',
				dataType:'json',
				contentType:'application/json;charset=utf-8',
				success:function(data){
					alert("timesheet is successfuly saved")
				},
				error:function(XHR,status,er){
					
				}
			});
		};
	};
	ko.applayBindings(new timesheetModel());
});
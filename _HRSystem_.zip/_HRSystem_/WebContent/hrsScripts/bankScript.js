
$(document).ready(function(){
	
	 var bankViewModel = function(){
		var self = this;
		
		self.accountNumber = ko.observable();
 		self.bankName = ko.observable();
 		self.branchName = ko.observable();
 		self.accountType = ko.observable();
 		self.branchCode = ko.observable();
 		
 		var bankObject ={
 			
 			    accountNumber: self.accountNumber,
				bankName:self.bankName,
				branchName:self.branchName,
				accountType:self.accountType,
				branchCode:self.branchCode,
 		};
 		
 		self.saveBankDetails = function(){
 			$.ajax({
 				 data: ko.toJSON(bankObject),
	 	            type:'POST',
	 	            url:'http://localhost:8080/HRSystem/hrs/BankController/saveBankDetails',
	 	            contentType: 'application/json',
	 	            dataType:"json",
	 	         success: function(data){
	 	        	 
	 	            alert("Bank details added");
	 	            console.log(data);
	 	            },
	 	         error: function (data, status)
	 	         {
	 	             alert("Failed" + status);
	 	         }
 			});
 		};
	 };
	 ko.applayBindings(new bankViewModel());
});
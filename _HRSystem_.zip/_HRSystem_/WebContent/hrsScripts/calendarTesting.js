$(document).ready(function()
{	
	$('#datetimepickerDefault').datetimepicker({
        showToday:true,
        useCurrent:true
    });
		 
         $('#datetimepicker1').datetimepicker({
             pickDate: false
         });
         $('#datetimepicker2').datetimepicker({
             pickDate: false
         });
         $('#datetimepicker3').datetimepicker({
             pickDate: false
         });
         $('#datetimepicker4').datetimepicker({
             pickDate: false
         });         
         $('#datetimepicker5').datetimepicker({
             pickDate: false
         });
         $('#datetimepicker11').datetimepicker({
             pickDate: false
         });
         $('#datetimepicker22').datetimepicker({
             pickDate: false
         });
         $('#datetimepicker33').datetimepicker({
             pickDate: false
         });
         $('#datetimepicker44').datetimepicker({
             pickDate: false
         });         
         $('#datetimepicker55').datetimepicker({
             pickDate: false
         });
         
         
         $('#datetimepicker8').datetimepicker();
         $('#datetimepicker9').datetimepicker();
         $("#datetimepicker8").on("dp.change",function (e) {
            $('#datetimepicker9').data("DateTimePicker").setMinDate(e.date);
         });
         $("#datetimepicker9").on("dp.change",function (e) {
            $('#datetimepicker8').data("DateTimePicker").setMaxDate(e.date);
         });
         
   //Full Calendar Below
         
         var date = new Date();
 		var d = date.getDate();
 		var m = date.getMonth();
 		var y = date.getFullYear();
 		
 		$('#calendar').fullCalendar({
 			header: {
 				left: 'prev,next today',
 				center: 'title',
 				right: 'month,basicWeek,basicDay'
 			},
 			
 			/*selectable: true,
			selectHelper: true,
			select: function(start, end, allDay) {
				var title = prompt('Event Title:');
				if (title) {
					calendar.fullCalendar('renderEvent',
						{
							title: title,
							start: start,
							end: end,
							allDay: allDay
						},
						true // make the event "stick"
					);
				}
				calendar.fullCalendar('unselect');
			},*/
 			
 			editable: true,
 			events: [
 				{
 					title: 'All Day Event',
 					start: new Date(y, m, 1)
 				},
 				{
 					title: 'Long Event',
 					start: new Date(y, m, d-5),
 					end: new Date(y, m, d-2)
 				},
 				{
 					id: 999,
 					title: 'Repeating Event',
 					start: new Date(y, m, d-3, 16, 0),
 					allDay: false
 				},
 				{
 					id: 999,
 					title: 'Repeating Event',
 					start: new Date(y, m, d+4, 16, 0),
 					allDay: false
 				},
 				{
 					title: 'Meeting',
 					start: new Date(y, m, d, 10, 30),
 					allDay: false
 				},
 				{
 					title: 'Lunch',
 					start: new Date(y, m, d, 12, 0),
 					end: new Date(y, m, d, 14, 0),
 					allDay: false
 				},
 				{
 					title: 'Birthday Party',
 					start: new Date(y, m, d+1, 19, 0),
 					end: new Date(y, m, d+1, 22, 30),
 					allDay: false
 				},
 				{
 					title: 'Click for Google',
 					start: new Date(y, m, 28),
 					end: new Date(y, m, 29),
 					url: 'http://google.com/'
 				}
 			]
 		});
         
         
});
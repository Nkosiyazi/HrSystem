$(document).ready(function(){
	
	
	var jobViewModel = function(){
		
		var self = this;
		self.jobTitle = ko.observable();
		self.jobLevel = ko.observable();
		self.jobLocation = ko.observable();
		self.jobCategory = ko.observable();
		self.noOfPositions = ko.observable();
		self.jobType = ko.observable();
		self.jobDescription = ko.observable();
		self.probitionPeriod = ko.observable();
		self.startDate = ko.observable();
		self.endDate = ko.observable();
		self.grade = ko.observable();
		self.department = ko.observable();
		
		
           var jobObject = {
				
				jobTitle: self.jobTitle,
				jobLevel: self.jobLevel,
				jobLocation:self.jobLocation,
				jobCategory:self.jobCategory,
				noOfPositions:self.noOfPositions,
				jobType:self.jobType,
				jobDescription:self.jobDescription,
				probitionPeriod:self.probitionPeriod,
				startDate:self.startDate,
				endDate:self.endDate,
				grade:self.grade,
				department:self.department
		};
           
           self.departmentList = ko.observableArray([]);
           
   		$.getJSON('http://localhost:8080/HRSystem/hrs/DepartmentController/departmentList',null,function(departmetnData,status,xhr){
   			$.each(departmetnData,function(index,value){
   				self.departmentList.push(value);
   			});
   		});
   		
        self.gradeList = ko.observableArray([]);
		
		
		$.getJSON('http://localhost:8080/HRSystem/hrs/GradeController/gradesList',null,function(gradeData,status,xhr){
			$.each(gradeData,function(index,value){ 
				self.gradeList.push(value);
				console.log(value)
			});
		});
		self.saveJob = function(){
			$.ajax({
				
				data:ko.toJSON(jobObject),
				type:'POST',
				url:'http://localhost:8080/HRSystem/hrs/JobController/saveJob',
				dataType:'json',
				contentType:'application/json;charset=utf-8',
				success:function(data){
					alert("job is successfuly saved")
				},
				error:function(XHR,status,er){
					
				}
			});
			
		};
	};
	ko.applyBindings(new jobViewModel());
});

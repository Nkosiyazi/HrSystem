$(document).ready(function(){
	
	function trainingViewModel(){
		
		this.trainingnName = ko.observable();
		this.trainingLocation = ko.observable();
		this.trainingDescription = ko.observable();
		this.startingDate = ko.observable();
		this.endDate = ko.observable();
		this.employees = ko.observableArray([]);
		
	}
	
	var showEmployees = function(){
		
				var self = this;
				
				self.employeeList = ko.observableArray([]);
				
				$.getJSON('http://localhost:8080/HRSystem/hrs/employeeController/employeeList',null,function(data,status,xhr){
					
					$.each(data,function(index,value)
	 							{
	 								self.employeeList.push(value);
	 							});
					
		        });
			
	}
	
	var removeEmployees = function(){
		
		var self = this;
		
		self.employeeList = ko.observableArray([]);
		self.selectedEmployees = ko.observableArray([]);
		
		$.getJSON('http://localhost:8080/HRSystem/hrs/employeeController/employeeList',null,function(data,status,xhr){
			
			$.each(data,function(index,value)
							{
								self.employeeList.remove(value);
								self.selectedEmployees.push(value);
							});
			
        });
		
		
	
}
	ko.applyBindings(new trainingViewModel());
	
});